# Change Log - @microsoft/generator-sharepoint

This log was last generated on Mon, 06 Jan 2020 18:14:52 GMT and should not be manually modified.

## 1.10.0
Mon, 06 Jan 2020 18:14:52 GMT

### Updates

- Remove erroneous white space character from React template import line breaking TSC compilation
- Fix casing of ClientSideInstance.xml for case-sensitive file systems
- Update @microsoft/rush-stack-compiler to 3.3
- Suppress ms-Grid camelcase warning breaking ship builds
- Support for SearchQueryModifier
- Fix issue with extra spaces in ts files
- Updating property pane api imports for web parts
- update @types/jest to match current jest version

