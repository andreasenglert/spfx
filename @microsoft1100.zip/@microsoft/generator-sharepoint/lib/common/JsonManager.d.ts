import * as yeoman from 'yeoman-generator';
export declare abstract class JsonManager<T> {
    protected _filepath: string;
    protected _fs: yeoman.MemFsEditor;
    protected _data: T;
    set(newData: T): T;
    merge(newData: T): T;
    readonly data: T;
    save(): void;
    protected constructor(_filepath: string, _fs: yeoman.MemFsEditor, _data: T);
}
//# sourceMappingURL=JsonManager.d.ts.map