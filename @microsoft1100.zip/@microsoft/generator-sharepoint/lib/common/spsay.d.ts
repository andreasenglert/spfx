export default function spsay(solutionName: string): string;
//# sourceMappingURL=spsay.d.ts.map