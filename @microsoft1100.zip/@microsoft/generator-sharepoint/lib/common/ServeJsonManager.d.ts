import * as yeoman from 'yeoman-generator';
import { ISpfxServe, ISpfxServeSessionConfiguration } from '@microsoft/sp-build-core-tasks';
import { JsonManager } from './JsonManager';
export declare class ServeJsonManager extends JsonManager<ISpfxServe> {
    private static _instance;
    static load(filepath: string, fs: yeoman.MemFsEditor): void;
    static reset(): void;
    static readonly instance: ServeJsonManager;
    addConfiguration(name: string, configuration: ISpfxServeSessionConfiguration): void;
    setUpForWebParts(): void;
}
//# sourceMappingURL=ServeJsonManager.d.ts.map