import * as yeoman from 'yeoman-generator';
import { IPackageSolution } from '@microsoft/sp-build-core-tasks';
import { ISolutionContext } from '../generators/solution';
import { JsonManager } from './JsonManager';
export declare class PackageSolutionJsonManager extends JsonManager<IPackageSolution> {
    private static _instance;
    static load(filepath: string, fs: yeoman.MemFsEditor): void;
    static reset(): void;
    static readonly instance: PackageSolutionJsonManager;
    getSkipFeatureDeployment(): boolean;
    setUpSolution(solutionContext: ISolutionContext): void;
    addExtensionFeature(featureId: string, includeClientSideInstance: boolean): void;
}
//# sourceMappingURL=PackageSolutionJsonManager.d.ts.map