import yeoman = require('yeoman-generator');
import { BaseGenerator, IBaseOptions } from './BaseGenerator';
export declare function titleCase(str: string): string;
export declare function untokenize(str: string, props: Object): string;
export declare function filesIn(...args: string[]): string[];
export declare function checkSolutionFolder(generator: yeoman, solutionName: string): Promise<string>;
export declare function generateGuid(): string;
export declare function compose(generator: string, base: BaseGenerator<any, any>, options: IBaseOptions): void;
//# sourceMappingURL=utilities.d.ts.map