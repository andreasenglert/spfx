import * as yeoman from 'yeoman-generator';
import { JsonManager } from './JsonManager';
export interface ITeamsManifestData {
    componentId: string;
    componentName: string;
    componentDescription: string;
}
export interface IConfigurationTab {
    configurationUrl: string;
    canUpdateConfiguration: boolean;
    scopes: string[];
}
export interface ITeamsManifest {
    $schema: string;
    manifestVersion: string;
    packageName: string;
    id: string;
    version: string;
    developer: {
        name: string;
        websiteUrl: string;
        privacyUrl: string;
        termsOfUseUrl: string;
    };
    name: {
        short: string;
    };
    description: {
        short: string;
        full: string;
    };
    icons: {
        outline: string;
        color: string;
    };
    accentColor: string;
    configurableTabs: IConfigurationTab[];
    validDomains: string[];
    webApplicationInfo: {
        resource: string;
        id: string;
    };
}
export declare class TeamsManifestJsonManager extends JsonManager<ITeamsManifest> {
    private static _instance;
    static load(filepath: string, fs: yeoman.MemFsEditor): void;
    static reset(): void;
    static readonly instance: TeamsManifestJsonManager;
    setUpManifest(teamsManifestData: ITeamsManifestData): void;
}
//# sourceMappingURL=TeamsManifestJsonManager.d.ts.map