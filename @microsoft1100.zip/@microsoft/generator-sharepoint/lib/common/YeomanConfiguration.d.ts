export interface IYeomanConfigurationData {
    set: (key: string, params: Object) => void;
    get: (key: string) => any;
}
/**
 * This class wraps an untyped property bag with types for
 * the generator.
 */
export declare class YeomanConfiguration {
    private static _store;
    static setStore(yeomanConfiguration: IYeomanConfigurationData): void;
    static libraryName: string;
    static version: string;
    static libraryId: string;
    static environment: 'spo' | 'onprem' | 'onprem19';
    static packageManager: 'npm' | 'pnpm' | 'yarn';
}
//# sourceMappingURL=YeomanConfiguration.d.ts.map