import { IPackageJson } from '@microsoft/node-core-library';
import * as yeoman from 'yeoman-generator';
import { JsonManager } from './JsonManager';
export interface IExtendedPackageJson extends IPackageJson {
    resolutions?: {
        [key: string]: string;
    };
}
export declare class PackageJsonManager extends JsonManager<IExtendedPackageJson> {
    private static _instance;
    static load(filepath: string, fs: yeoman.MemFsEditor): void;
    static reset(): void;
    static readonly instance: PackageJsonManager;
    addDependency(dependency: string, version: string): void;
    addResolution(dependency: string, resolution: string): void;
}
//# sourceMappingURL=PackageJsonManager.d.ts.map