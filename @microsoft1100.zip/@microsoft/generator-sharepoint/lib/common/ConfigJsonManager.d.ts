import * as yeoman from 'yeoman-generator';
import { IConfigJson, IConfigBundle } from '@microsoft/sp-build-core-tasks';
import { IConfigJson as IV1ConfigJson } from '@microsoft/sp-build-core-tasks/lib/configJson/interfaces/config-v1';
import { JsonManager } from './JsonManager';
export declare class ConfigJsonManager extends JsonManager<IConfigJson | IV1ConfigJson> {
    configJsonIsV1: boolean;
    private static _instance;
    static load(filepath: string, fs: yeoman.MemFsEditor): void;
    static reset(): void;
    static readonly instance: ConfigJsonManager;
    addEntry(bundleEntry: IConfigBundle, name: string): void;
    addLocalizedResource(localizedResourceKey?: string, localizedResourcePath?: string): void;
    private constructor();
    private _translateV2BundleIntoV1;
}
//# sourceMappingURL=ConfigJsonManager.d.ts.map