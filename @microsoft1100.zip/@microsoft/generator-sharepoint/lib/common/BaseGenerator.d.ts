import * as yeoman from 'yeoman-generator';
import { PackageJsonManager } from './PackageJsonManager';
import { ConfigJsonManager } from './ConfigJsonManager';
import { ServeJsonManager } from './ServeJsonManager';
import { PackageSolutionJsonManager } from './PackageSolutionJsonManager';
export declare type AvailableFrameworks = 'react' | 'none' | 'knockout';
export declare type DependencyGroups = 'react' | 'none' | 'knockout' | 'extension' | 'webpart' | 'applicationCustomizer' | 'fieldCustomizer' | 'commandSet' | 'searchQueryModifier' | 'library';
export interface IBaseOptions {
    'skip-install': boolean;
    'plusbeta': boolean;
}
export declare abstract class BaseGenerator<IOptions extends IBaseOptions, IContext> extends yeoman {
    protected static generatorPackageJson: any;
    private static _hasCheckedForUpdates;
    /**
     * The options property bag created by yeoman
     */
    options: IOptions;
    /**
     * The context property bag used by templates
     */
    context: IContext;
    protected abstract friendlyName: string;
    protected allowEmptyPackageJson: boolean;
    protected readonly packageJson: PackageJsonManager;
    protected readonly configJson: ConfigJsonManager;
    protected readonly serveJson: ServeJsonManager;
    protected readonly packageSolutionJson: PackageSolutionJsonManager;
    private _dependencyGroupMap;
    private static _checkForUpdates;
    /**
     * Lifecycle events, these are called in a specific order by the Yeoman
     * generator, which is why they are listed here in order.
     * http://yeoman.io/authoring/running-context.html
     */
    /** Your initialization methods (checking current project state, getting configs, etc) */
    abstract initializing(): Promise<any> | void;
    /** Where you prompt users for options (where you'd call this.prompt()) */
    abstract prompting(): Promise<any> | void;
    /** Saving configurations and configure the project (creating .editorconfig files and other metadata files) */
    abstract configuring(): Promise<any> | void;
    /** Where you write the generator specific files (routes, controllers, etc) */
    writing(shouldCopy?: boolean): Promise<any> | void;
    /** Where installation are run (npm, bower) */
    abstract install(): Promise<any> | void;
    /** Called last, cleanup, say good bye, etc */
    abstract end(): Promise<any> | void;
    protected constructor(args: string | string[], options: any);
    protected tryInstall(): boolean;
    protected copyTemplate(sourceDirectory: string, destinationDir: string): void;
    protected ensureCorrectFolder(): void;
    protected ensureDependencyGroup(group: DependencyGroups): void;
    private _addResoutionsIfApplicable;
    private _doPnpmInstall;
    private _getDependencies;
    private readonly _dependencyGroups;
    private _untokenizedCopier;
    private _getDependencyFileName;
}
//# sourceMappingURL=BaseGenerator.d.ts.map