import { BaseGenerator, IBaseOptions, AvailableFrameworks } from '../../common/BaseGenerator';
export interface IBaseComponentShared {
    framework: AvailableFrameworks;
    componentDescription: string;
}
export interface IBaseComponentOptions extends IBaseComponentShared, IBaseOptions {
    componentName: string;
    creatingSolution: boolean;
}
export interface IBaseComponentContext extends IBaseComponentShared {
    componentId: string;
    componentName: string;
    componentNameCamelCase: string;
    componentClassName: string;
    componentClassNameKebabCase: string;
    componentAlias: string;
    componentStrings: string;
    componentNameUnescaped: string;
}
export declare function defineOptions(generator: BaseGenerator<any, any>, type: string): void;
export declare abstract class BaseComponentGenerator<IOptions extends IBaseComponentOptions, IContext extends IBaseComponentContext> extends BaseGenerator<IOptions, IContext> {
    /** The friendly name of this component, which appears in the UI */
    protected abstract readonly friendlyName: string;
    /** The class extension of the component. Is used for the alias in manifest and class name in templates */
    protected abstract readonly codeName: string;
    /** The name of the folder that this comonent should have its template copied to */
    protected abstract readonly folderName: string;
    protected abstract readonly allowedFrameworks: AvailableFrameworks[];
    prompting(): Promise<void>;
    configuring(): void;
    writing(shouldWrite?: boolean): void;
    install(): void;
    private _getOutputFolder;
    private checkSolution;
}
export interface INormalizedComponentNames {
    componentNameUnescaped: string;
    componentName: string;
    componentNameCamelCase: string;
    componentClassName: string;
    componentStrings: string;
    componentClassNameKebabCase: string;
    componentAlias: string;
}
export declare function normalizeComponentNames(componentNameUnescaped: string, componentType: string): INormalizedComponentNames;
//# sourceMappingURL=BaseComponentGenerator.d.ts.map