import { BaseGenerator, IBaseOptions } from '../../common/BaseGenerator';
export interface ISolutionOptions extends IBaseOptions {
    solutionName: string;
    skipFeatureDeployment: boolean;
    environment: 'spo' | 'onprem';
    packageManager: 'npm' | 'pnpm' | 'yarn';
    isDomainIsolated: boolean;
}
export interface ISolutionContext extends ISolutionOptions {
    libraryName: string;
    libraryId: string;
}
export declare function composeWith(base: BaseGenerator<any, any>, options: IBaseOptions): void;
export declare function defineOptions(generator: BaseGenerator<any, any>): void;
//# sourceMappingURL=index.d.ts.map