declare interface I<%= componentStrings %> {
  Title: string;
}

declare module '<%= componentStrings %>' {
  const strings: I<%= componentStrings %>;
  export = strings;
}
