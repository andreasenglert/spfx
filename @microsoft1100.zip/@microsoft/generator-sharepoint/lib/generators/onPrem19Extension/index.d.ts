import { IBaseOptions, BaseGenerator } from '../../common/BaseGenerator';
import * as FieldCustomizer from '../fieldCustomizer';
import * as CommandSet from '../commandSet';
import * as ApplicationCustomizer from '../applicationCustomizer';
import * as BaseExtension from '../extension/BaseExtensionGenerator';
export interface IExtensionOptions extends FieldCustomizer.IFieldCustomizerOptions, CommandSet.ICommandSetOptions, ApplicationCustomizer.IApplicationCustomizerOptions {
    extensionType: BaseExtension.AvailableExtensions;
}
export declare function defineOptions(generator: BaseGenerator<any, any>): void;
export declare function composeWith(base: BaseGenerator<any, any>, options: IBaseOptions): void;
/**
 * This class selects between multiple different types of extensions for instantiation.
 */
export declare class ExtensionSelectorGenerator extends BaseGenerator<IExtensionOptions, {}> {
    readonly friendlyName: string;
    initializing(): void;
    prompting(): Promise<void>;
    configuring(): void;
    writing(): void;
    install(): void;
    end(): void;
    protected constructor(args: string | string[], options: any);
    private shouldExecute;
}
//# sourceMappingURL=index.d.ts.map