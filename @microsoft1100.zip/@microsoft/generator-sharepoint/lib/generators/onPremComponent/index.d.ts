import { IBaseOptions, BaseGenerator } from '../../common/BaseGenerator';
import * as OnPremWebpart from '../onPremWebpart';
export interface IComponentSelectorOptions extends OnPremWebpart.IWebpartOptions {
    componentType: 'webpart';
}
export declare function composeWith(base: BaseGenerator<any, any>, options: IBaseOptions): void;
export declare function defineOptions(generator: BaseGenerator<any, any>): void;
/**
 * This class selects between multiple different types of components for instantiation.
 */
export declare class ComponentSelectorGenerator extends BaseGenerator<IComponentSelectorOptions, {}> {
    friendlyName: string;
    initializing(): void;
    prompting(): Promise<void>;
    configuring(): void;
    writing(): void;
    install(): void;
    end(): void;
    private shouldExecute;
}
//# sourceMappingURL=index.d.ts.map