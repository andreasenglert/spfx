import { IBaseOptions, BaseGenerator } from '../../common/BaseGenerator';
import * as Webpart from '../webpart';
import * as Extension from '../extension';
export interface IComponentSelectorOptions extends Webpart.IWebpartOptions, Extension.IExtensionOptions {
    componentType: 'webpart' | 'extension';
}
export declare function composeWith(base: BaseGenerator<any, any>, options: IBaseOptions): void;
export declare function defineOptions(generator: BaseGenerator<any, any>): void;
/**
 * This class selects between multiple different types of components for instantiation.
 */
export declare class ComponentSelectorGenerator extends BaseGenerator<IComponentSelectorOptions, {}> {
    readonly friendlyName: string;
    initializing(): void;
    prompting(): Promise<void>;
    configuring(): void;
    writing(): void;
    install(): void;
    end(): void;
    private shouldExecute;
}
//# sourceMappingURL=index.d.ts.map