export interface I<%= componentName %>Props {
  description: string;
}
