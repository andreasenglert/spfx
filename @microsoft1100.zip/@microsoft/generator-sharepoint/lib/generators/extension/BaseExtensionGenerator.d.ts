import { BaseGenerator } from '../../common/BaseGenerator';
import * as BaseComponent from '../component/BaseComponentGenerator';
export declare type AvailableExtensions = 'ApplicationCustomizer' | 'FieldCustomizer' | 'CommandSet' | 'SearchQueryModifier';
export interface IBaseExtensionOptions extends BaseComponent.IBaseComponentOptions {
}
export interface IBaseExtensionContext extends BaseComponent.IBaseComponentContext {
}
export declare function defineOptions(generator: BaseGenerator<any, any>, type?: string): void;
export declare abstract class BaseExtensionGenerator<IOptions extends IBaseExtensionOptions, IContext extends IBaseExtensionContext> extends BaseComponent.BaseComponentGenerator<IOptions, IContext> {
    protected readonly folderName: string;
    prompting(): Promise<void>;
    configuring(): void;
    writing(shouldCopy?: boolean): void;
    install(): void;
    protected abstract includeClientSideInstances(): boolean;
    private hasElementsXml;
}
//# sourceMappingURL=BaseExtensionGenerator.d.ts.map