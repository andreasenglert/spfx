import { IBaseOptions, BaseGenerator, AvailableFrameworks } from '../../common/BaseGenerator';
import * as BaseComponent from '../component/BaseComponentGenerator';
export interface ILibraryOptions extends BaseComponent.IBaseComponentOptions {
}
export interface ILibraryContext extends BaseComponent.IBaseComponentContext {
}
export declare function composeWith(base: BaseGenerator<any, any>, options: IBaseOptions): void;
export declare function defineOptions(generator: BaseGenerator<any, any>): void;
export declare class LibraryGenerator extends BaseComponent.BaseComponentGenerator<ILibraryOptions, ILibraryContext> {
    protected readonly friendlyName: string;
    protected readonly codeName: string;
    protected readonly allowedFrameworks: AvailableFrameworks[];
    protected readonly folderName: string;
    initializing(): void;
    prompting(): Promise<void>;
    configuring(): void;
    writing(): void;
    install(): void;
    end(): void;
    protected constructor(args: string | string[], options: any);
    private shouldExecute;
}
//# sourceMappingURL=index.d.ts.map