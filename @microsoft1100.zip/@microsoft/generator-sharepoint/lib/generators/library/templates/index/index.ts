export { <%= componentClassName %> } from './libraries/<%= componentNameCamelCase %>/<%= componentClassName %>';
