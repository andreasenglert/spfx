export class <%= componentClassName %> {
  public name(): string {
    return '<%= componentClassName %>';
  }
}
